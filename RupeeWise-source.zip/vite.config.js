import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react';
export default defineConfig({ plugins:[react()], server:{host:'0.0.0.0', allowedHosts:true, proxy:{'/api':'http://localhost:5000'}}, build:{outDir:'dist'} });
